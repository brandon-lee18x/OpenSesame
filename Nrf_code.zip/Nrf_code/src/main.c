#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <zephyr/device.h>
#include <zephyr/drivers/pwm.h>

static const struct pwm_dt_spec pwm_led0 = PWM_DT_SPEC_GET(DT_ALIAS(pwm_led0));

int main(void)
{
	printk("SERVO test\n");

	if (!pwm_is_ready_dt(&pwm_led0)) {
		printk("Error: PWM device %s is not ready\n",
		       pwm_led0.dev->name);
		return 0;
	}

	int ret;
	int period = PWM_MSEC(20);
	while (1) {
		ret = pwm_set_dt(&pwm_led0, period, PWM_MSEC(1));
		k_sleep(K_SECONDS(1));
		ret = pwm_set_dt(&pwm_led0, period, PWM_MSEC(2));
		k_sleep(K_SECONDS(1));
	}
	return 0;
}
